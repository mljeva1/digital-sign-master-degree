<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('certificates', function (Blueprint $table) {
            $table->id();
            $table->string('owner_type', 20)->comment('user, customer');
            $table->foreignId('owner_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('owner_customer_id')->nullable()->constrained('customers')->nullOnDelete();
            $table->string('label', 255);
            $table->string('subject_dn', 500)->comment('Distinguished Name subjekta');
            $table->string('issuer_dn', 500)->comment('Distinguished Name izdavatelja');
            $table->string('serial_number', 255);
            $table->timestampTz('valid_from');
            $table->timestampTz('valid_to');
            $table->char('thumbprint_sha256', 64)->unique()->comment('SHA-256 otisak certifikata');
            $table->foreignId('file_id')->constrained('files')->restrictOnDelete();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('owner_user_id');
            $table->index('owner_customer_id');
            $table->index('thumbprint_sha256');
            $table->index('file_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('certificates');
    }
};
